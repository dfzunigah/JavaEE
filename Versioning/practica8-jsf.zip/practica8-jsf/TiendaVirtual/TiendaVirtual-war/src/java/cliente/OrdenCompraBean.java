/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import entidades.Comprador;
import entidades.InformacionEnvio;
import entidades.InformacionFactura;
import entidades.Producto;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import logica.AdministracionOrdenLocal;
import logica.AdministracionPersistenciaJPALocal;

/**
 *
 * @author JAVS
 */
@Named(value = "ordenCompraBean")
@SessionScoped
public class OrdenCompraBean implements Serializable {

    @EJB
    AdministracionPersistenciaJPALocal administracionPersistencia;

    @EJB
    AdministracionOrdenLocal administracionOrden;

    private InformacionEnvio informacionEnvio;
    
    private InformacionFactura informacionFactura;

    /**
     * Creates a new instance of OrdenCompraBean
     */
    public OrdenCompraBean() {
        informacionEnvio = new InformacionEnvio();
        informacionFactura = new InformacionFactura();
    }

    public List<Comprador> getCompradores() {
        return administracionPersistencia.consultarCompradores();
    }

    public void compradoresListener(ValueChangeEvent vce) {
        String login = vce.getNewValue().toString();
        if (!login.equals("-1")) {
            Comprador comprador = administracionPersistencia.consultarComprador(login);
            administracionOrden.adicionarComprador(comprador);
        }
    }

    public List getProductos() {
        return administracionPersistencia.consultarProductos();
    }

    public void adicionarProducto(Producto producto) {
        administracionOrden.adicionarProducto(producto);
    }

    public List getCarroCompras() {
        return administracionOrden.consultarCarroCompras();
    }

    public InformacionEnvio getInformacionEnvio() {
        return informacionEnvio;
    }

    public void setInformacionEnvio(InformacionEnvio informacionEnvio) {
        this.informacionEnvio = informacionEnvio;
    }

    public String adicionarInformacionEnvio() {
        administracionOrden.adicionarInformacionEnvio(informacionEnvio);
        return "informacion_factura";
    }
    
    public InformacionFactura getInformacionFactura() {
        return informacionFactura;
    }

    public void setInformacionFactura(InformacionFactura informacionFactura) {
        this.informacionFactura = informacionFactura;
    }
    
    public void crearOrdenCompra() {
        
        administracionOrden.adicionarInformacionFactura(informacionFactura);
        administracionOrden.crearOrdenCompra();

        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Orden creada exitosamente.", "");
        FacesContext.getCurrentInstance().addMessage(null, message);
        
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().
                remove("OrdenCompraBean");
        
    }
}
