/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import entidades.*;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author JAVS
 */
@Local
public interface AdministracionPersistenciaLocal {
    public Producto consultarProducto(int idProducto);

    public Integer crearOrden(Orden orden);

    public Integer crearInformacionEnvio(InformacionEnvio ie);

    public Integer crearInformacionFactura(InformacionFactura infFac);

    public void modificarProductos(List<Producto> productos, Orden orden);
}
