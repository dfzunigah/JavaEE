/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notificaciones;

import entidades.InformacionFactura;
import entidades.Orden;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author JAVS
 */
public class EntidadFinancieraInterceptor {
    
    @PersistenceContext(unitName = "TiendaVirtual-ejbPU2")
    private EntityManager em;
    
    @AroundInvoke
    public Object crearInformacionFinanciera(InvocationContext ic) throws Exception {
        Object[] object = ic.getParameters();
        Orden orden = (Orden) object[0];
        InformacionFactura informacionFactura = orden.getInformacionFactura();
        em.persist(informacionFactura);
        return ic.proceed();
    }
}
