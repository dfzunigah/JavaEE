/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package auditoria;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author javs
 */
public class TiendaVirtualInterceptor {

    @AroundInvoke
    public Object interceptor(InvocationContext ic) throws Exception {

        System.out.println("Se va a ejecutar el método " + ic.getMethod().getName());
        return ic.proceed();

    }
}
