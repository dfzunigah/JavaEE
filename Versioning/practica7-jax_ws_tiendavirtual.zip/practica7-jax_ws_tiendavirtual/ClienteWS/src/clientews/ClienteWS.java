/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientews;

import java.util.Date;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import ws.*;

/**
 *
 * @author Andres
 */
public class ClienteWS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AdministracionPersistenciaJPAWS_Service service = new AdministracionPersistenciaJPAWS_Service();
        AdministracionPersistenciaJPAWS port = service.getAdministracionPersistenciaJPAWSPort();
        Comprador comprador = port.consultarComprador("pedro");
        
        InformacionEnvio informacionEnvio = new InformacionEnvio();
        informacionEnvio.setCiudad("BOGOTA");
        informacionEnvio.setDepartamento("CUNDINAMARCA");
        informacionEnvio.setPais("COLOMBIA");
        informacionEnvio.setDireccion("CR50 N30-22");
        informacionEnvio.setId(port.crearInformacionEnvio(informacionEnvio));
        
        InformacionFactura informacionFactura = new InformacionFactura();
        informacionFactura.setCodigoTarjeta("0001");
        informacionFactura.setNumeroTarjeta("123456789");
        try {
            DatatypeFactory df = DatatypeFactory.newInstance();
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTimeInMillis(new Date().getTime());
            informacionFactura.setFechaExpiracion(df.newXMLGregorianCalendar(gc));
        } catch (DatatypeConfigurationException ex) {
            System.out.println("error fecha: " + ex.toString());
        }
        informacionFactura.setId(port.crearInformacionFactura(informacionFactura));
        
        Orden orden = new Orden();
        orden.setComprador(comprador);
        orden.setInformacionEnvio(informacionEnvio);
        orden.setInformacionFactura(informacionFactura);
        port.crearOrden(orden);
    }
    
}
