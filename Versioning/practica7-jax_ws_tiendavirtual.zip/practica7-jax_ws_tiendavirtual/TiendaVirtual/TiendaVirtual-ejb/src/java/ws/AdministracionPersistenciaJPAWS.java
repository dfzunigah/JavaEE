/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import entidades.Comprador;
import entidades.InformacionEnvio;
import entidades.InformacionFactura;
import entidades.Orden;
import entidades.Producto;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import logica.AdministracionPersistenciaJPALocal;

/**
 *
 * @author Andres
 */
@WebService(serviceName = "AdministracionPersistenciaJPAWS")
@Stateless()
public class AdministracionPersistenciaJPAWS {

    @EJB
    private AdministracionPersistenciaJPALocal ejbRef;

    @WebMethod(operationName = "consultarProducto")
    public Producto consultarProducto(@WebParam(name = "idProducto") int idProducto) {
        return ejbRef.consultarProducto(idProducto);
    }

    @WebMethod(operationName = "crearOrden")
    public Integer crearOrden(@WebParam(name = "orden") Orden orden) {
        return ejbRef.crearOrden(orden);
    }

    @WebMethod(operationName = "crearInformacionEnvio")
    public Integer crearInformacionEnvio(@WebParam(name = "ie") InformacionEnvio ie) {
        return ejbRef.crearInformacionEnvio(ie);
    }

    @WebMethod(operationName = "crearInformacionFactura")
    public Integer crearInformacionFactura(@WebParam(name = "infFac") InformacionFactura infFac) {
        return ejbRef.crearInformacionFactura(infFac);
    }

    @WebMethod(operationName = "modificarProductos")
    @Oneway
    public void modificarProductos(@WebParam(name = "productos") List<Producto> productos, @WebParam(name = "orden") Orden orden) {
        ejbRef.modificarProductos(productos, orden);
    }

    @WebMethod(operationName = "consultarComprador")
    public Comprador consultarComprador(@WebParam(name = "login") String login) {
        return ejbRef.consultarComprador(login);
    }
    
}
